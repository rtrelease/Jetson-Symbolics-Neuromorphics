See the CLIPS Interfaces Guide for instructions 
on compiling and running CLIPSJNI programs.